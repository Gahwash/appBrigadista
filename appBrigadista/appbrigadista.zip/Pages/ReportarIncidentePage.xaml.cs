﻿using appBrigadista.Models;
using appBrigadista.Services;

namespace appBrigadista.Pages
{
    public partial class ReportarIncidentePage : ContentPage
    {
        private readonly IncidenteService _incidenteService;
        private readonly RadioMapService _radioMapService;

        private List<RadioMapEntry> _zonas = new();

        public ReportarIncidentePage(
            IncidenteService incidenteService,
            RadioMapService radioMapService)
        {
            InitializeComponent();

            _incidenteService = incidenteService;
            _radioMapService = radioMapService;
        }

        protected override async void OnAppearing()
        {
            base.OnAppearing();

            await CargarZonasAsync();
        }

        private async Task CargarZonasAsync()
        {
            _zonas = await _radioMapService.ObtenerZonasAsync();

            ZonaPicker.ItemsSource = _zonas;

            if (_zonas.Count == 0)
            {
                await DisplayAlertAsync(
                    "Sin ubicaciones",
                    "No se encontraron zonas calibradas en el nodo.",
                    "Aceptar");
            }
        }

        private async void OnEnviarClicked(object sender, EventArgs e)
        {
            if (TipoPicker.SelectedItem == null)
            {
                await DisplayAlertAsync(
                    "Falta información",
                    "Selecciona un tipo de incidente.",
                    "Aceptar");
                return;
            }

            if (ZonaPicker.SelectedItem is not RadioMapEntry zona)
            {
                await DisplayAlertAsync(
                    "Falta ubicación",
                    "Selecciona la ubicación donde ocurrió el incidente.",
                    "Aceptar");
                return;
            }

            string usuarioId = Preferences.Get("usuario_id", "");

            if (string.IsNullOrWhiteSpace(usuarioId))
            {
                await DisplayAlertAsync(
                    "Sesión no disponible",
                    "No se encontró el identificador del usuario.",
                    "Aceptar");
                return;
            }

            var incidente = new IncidenteRequest
            {
                Tipo = TipoPicker.SelectedItem.ToString() ?? "",
                Descripcion = DescripcionEditor.Text?.Trim() ?? "",
                ReportadoPorId = usuarioId,
                ZonaId = zona.ZonaId,
                ZonaNombre = zona.ZonaNombre,
                Piso = zona.Piso,
                ConfianzaUbicacion = 1.0f
            };

            bool creado = await _incidenteService.CrearAsync(incidente);

            if (!creado)
            {
                await DisplayAlertAsync(
                    "Error",
                    "No fue posible enviar el reporte.",
                    "Aceptar");
                return;
            }

            await DisplayAlertAsync(
                "Reporte enviado",
                "El incidente fue reportado correctamente.",
                "Aceptar");

            await Navigation.PopModalAsync();
        }

        private async void OnCancelarClicked(object sender, EventArgs e)
        {
            await Navigation.PopModalAsync();
        }
    }
}
